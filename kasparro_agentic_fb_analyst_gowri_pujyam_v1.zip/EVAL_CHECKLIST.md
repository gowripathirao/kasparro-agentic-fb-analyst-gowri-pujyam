# Self-review checklist

- [ ] Repo public and named correctly
- [ ] README explains how to run
- [ ] data/ contains CSV used
- [ ] outputs/ has insights.json, creatives.json, report.md
- [ ] Code is modular (agents/planner.py, evaluator.py, generator.py)
- [ ] v1.0 release tag created
- [ ] Commit history is reasonable and clear
